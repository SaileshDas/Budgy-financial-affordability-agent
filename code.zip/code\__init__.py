"""Financial affordability agent package."""
